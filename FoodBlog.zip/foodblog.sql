-- phpMyAdmin SQL Dump
-- version 3.5.2.2
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jan 19, 2017 at 11:24 AM
-- Server version: 5.5.27
-- PHP Version: 5.4.7

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `foodblog`
--

-- --------------------------------------------------------

--
-- Table structure for table `blogtable`
--

CREATE TABLE IF NOT EXISTS `blogtable` (
  `BlogTitle` varchar(100) NOT NULL,
  `BlogImage` varchar(100) NOT NULL,
  `BlogText` text NOT NULL,
  `BlogUser` varchar(30) NOT NULL,
  `BlogID` int(11) NOT NULL AUTO_INCREMENT,
  `BlogDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`BlogID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `blogtable`
--

INSERT INTO `blogtable` (`BlogTitle`, `BlogImage`, `BlogText`, `BlogUser`, `BlogID`, `BlogDate`) VALUES
('Martabak Boss', 'martabak boss.jpg', 'Berlokasi di Menteng, Martabak Boss menawarkan pengalaman makan martabak dengan sensasi dan rasa berbeda. Bentuk tokonya saja sudah unik, berbentuk seperti kontainer kapal yang berwarna kuning dan bergambar karikatur. Selain menawarkan martabak original seperti martabak manis dan martabak telor, Martabak Boss juga menawarkan martabak nutella, martabak skippy, martabak duren, martabak nanas, martabak ovomaltine, martabak toblerone, sampai dengan martabak pandan. Walau harganya lumayan mahal, sebaiknya Anda datang sebelum jam 6 sore karena di atas jam 6 sore antrian akan mulai panjang, sehingga Anda harus menunggu sampai dengan 1 jam untuk dapat menikmati martabak pesanan Anda.', 'test1', 5, '2017-01-19 09:06:24'),
('Jemahdi Seafood', 'jemahdi.jpg', 'Restoran Jemahdi Seafood adalah tempat yang cocok untuk pecinta kuliner seafood. Menawarkan konsep restoran yang nyaman dan family friendly, Jemahdi Seafood akan menjamu setiap pengunjung seperti di rumah sendiri. Setiap hidangan yang dimasak di Jemahdi Seafood akan dimasak oleh chef yang berpengalaman mengolah hidangan laut sehingga dengan cita rasa yang menggoda lidah dan harga yang terjangkau, restoran ini harus dikunjungi para pecinta seafood. Jemahdi Seafood berlokasi di Pluit, Pantai Indah Kapuk, dan Pesanggrahan.', 'test2', 6, '2017-01-19 09:09:00'),
('Magnum Cafe', 'magnum cafe.jpg', 'Magnum Cafe adalah surganya para pecinta es krim dan coklat. Berlokasi di Grand Indonesia Mall dan Pondok Indah Mall, Magnum Cafe menawarkan cara lain untuk menikmati es krim magnum. Selain es krim magnum yang dimodifikasi, Magnum Cafe juga menawarkan hidangan ringan lain seperti kentang goreng berbagai rasa, spaghetti, kue, waffle, calamari, dan lain-lain. Restoran yang terkenal dengan hidangan penutupnya ini akan sangat ramai pada akhir pekan, walaupun harganya terbilang cukup mahal, sekitar 45.000 Rupiah per es krim.', 'test2', 7, '2017-01-19 09:10:56'),
('Sengoku Noodle', 'sengoku noodle.jpg', 'Sengoku Noodle adalah tempat makan di Pantai Indah Kapuk yang cukup terkenal dengan ramennya yang enak dan harganya terjangkau, mulai dari 30.000 Rupiah saja Anda sudah dapat menikmati seporsi ramen yang nikmat. Restoran yang menyediakan tempat makan indoor dan outdoor ini sering muncul di website-website daily deals atau kupon sehingga Anda dapat makan di tempat ini dengan harga yang cukup murah, namun perlu diingat bahwa menu yang ada di sini rata-rata mengandung babi.', 'test3', 8, '2017-01-19 09:21:39'),
('tony romas', 'tony romas.jpg', 'Tony Romaâ??s adalah tempat makan iga bakar paling enak di Jakarta. Harganya yang cukup mahal mungkin akan menjadi kendala bagi sebagian orang, namun bagi yang telah mencoba makan di Tony Romaâ??s, maka akan tahu kenapa harganya lumayan mahal. Menggunakan bahan terbaik dan dilengkapi dengan bumbu rahasia, Tony Romaâ??s menawarkan porsi makanan yang cukup besar sehingga Anda tidak akan menyesal membayar mahal. Menu andalan dari restoran ini adalah iga dan steak. Tony Romaâ??s Jakarta buka dari jam 11 siang sampai dengan 11 malam, berlokasi di Gandaria City, Puri Indah, dan Thamrin.', 'test3', 9, '2017-01-19 09:22:10');

-- --------------------------------------------------------

--
-- Table structure for table `usertable`
--

CREATE TABLE IF NOT EXISTS `usertable` (
  `FullName` varchar(30) NOT NULL,
  `UserName` varchar(30) NOT NULL,
  `UserEmail` varchar(30) NOT NULL,
  `UserPassword` varchar(30) NOT NULL,
  `UserBirthdate` date NOT NULL,
  `UserID` int(11) NOT NULL AUTO_INCREMENT,
  `UserRole` varchar(20) NOT NULL,
  PRIMARY KEY (`UserID`),
  UNIQUE KEY `UserName` (`UserName`,`UserEmail`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `usertable`
--

INSERT INTO `usertable` (`FullName`, `UserName`, `UserEmail`, `UserPassword`, `UserBirthdate`, `UserID`, `UserRole`) VALUES
('qweqwe', 'test1', 'qwe@gmail.com', 'qweQWE123', '1990-10-22', 1, 'member'),
('admin', 'admin1', 'iniadmin@gmail.com', 'iniADMIN1', '2015-12-08', 2, 'admin'),
('testdua', 'test2', 'initestdua@yahoo.com', 'qweQWE123', '1990-08-20', 3, 'member'),
('testketiga', 'test3', 'initest3@gmail.com', 'qweQWE123', '1982-10-20', 4, 'member');

-- --------------------------------------------------------

--
-- Table structure for table `videotable`
--

CREATE TABLE IF NOT EXISTS `videotable` (
  `VideoTitle` varchar(225) NOT NULL,
  `Video` varchar(100) NOT NULL,
  `VideoDescription` text NOT NULL,
  `VideoUser` varchar(30) NOT NULL,
  `VideoID` int(11) NOT NULL AUTO_INCREMENT,
  `VideoDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`VideoID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `videotable`
--

INSERT INTO `videotable` (`VideoTitle`, `Video`, `VideoDescription`, `VideoUser`, `VideoID`, `VideoDate`) VALUES
('Tutorial Memasak Burger Tempe', 'Dapur Umami - Burger Tempe.mp4', 'Source By Youtube', 'test2', 2, '2017-01-19 09:19:26');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
